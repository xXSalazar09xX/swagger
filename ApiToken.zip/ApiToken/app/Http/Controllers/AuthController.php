<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
Use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;



class AuthController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $usuario=User::where('estado',true)->get();
        return response()->json(['usuario'=>$usuario],200);
    }

    /*
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validateUsuario = Validator::make($request->all(),
            [
                'name' => 'required',
                'email' =>                  
                'required|email|unique:users,email',
                'password' => 'required'
            ]);
            if($validateUsuario->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'Existen campos vacios',
                    'errors' => $validateUsuario->errors()
                ], 401);
            }
            $usuario = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
            ]);
            return response()->json([
                'message' => 'Usuario creado correctamente',
                'token' => $usuario->createToken("API TOKEN")->plainTextToken
            ], 201);

        
    }
    public function logear(Request $request){
        $validateUsuario = Validator::make(
            $request->all(),
            [
                'email' => 'required',
                'password' => 'required'
            ]
        );
        if ($validateUsuario->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validaciones requeridas',
                'errors' => $validateUsuario->errors()
            ], 401);
        }
        if(!Auth::attempt($request->only(['email', 'password']))){
            return response()->json([
                'status' => false,
                'message' => 'Credenciales incorrectas',
            ], 401);
        }
        $user = User::where('email', $request->email)->first();
        return response()->json([
            "Usuario" => $user,
            'message' => 'Usuario logeado correctamente',
            'token' => $user->createToken("API TOKEN")->plainTextToken
        ], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        
    }
}
